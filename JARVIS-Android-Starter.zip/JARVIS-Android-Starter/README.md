# JARVIS AI — Android starter

A minimal Android starter app with Hindi speech recognition, Hindi text-to-speech, and a text input.

## Current scope
- Voice input via Android SpeechRecognizer (`hi-IN`)
- Spoken replies via Android TextToSpeech (`hi-IN`, if a Hindi voice is installed)
- Text input and a small local demo responder

**This is not yet a full ChatGPT-powered assistant.** The AI backend, secure API-key handling, app launching, calling and messaging actions are intentionally left for later stages.

## Build APK on GitHub
1. Create a new public or private GitHub repository named `jarvis-android`.
2. Upload the contents of this folder (not the ZIP itself) to the repository root.
3. Open **Actions** and allow workflows if GitHub asks.
4. Run **Build JARVIS APK** (or push to `main`).
5. Open the successful workflow run, find **Artifacts**, and download `JARVIS-debug-APK`.
6. Extract the ZIP and install `app-debug.apk`. Android may ask you to allow installs from your browser/files app.

## App permissions and privacy
The app requests microphone permission only when needed. Speech recognition may use the phone's configured recognition service and internet connection. Do not add API keys or passwords to the Android source code or public GitHub repository.

## Build locally
Requires JDK 17, Android SDK 35, and Gradle 8.9:
`gradle assembleDebug`
